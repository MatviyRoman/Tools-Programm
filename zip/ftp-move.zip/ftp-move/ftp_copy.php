<?php

  function getchmod($perm)
  {
    $chmod = 0;
    if($perm[0] == "r") $chmod = $chmod+0400;
    if($perm[1] == "w") $chmod = $chmod+0200;
    if($perm[2] == "x") $chmod = $chmod+0100;
    if($perm[3] == "r") $chmod = $chmod+0040;
    if($perm[4] == "w") $chmod = $chmod+0020;
    if($perm[5] == "x") $chmod = $chmod+0010;
    if($perm[6] == "r") $chmod = $chmod+0004;
    if($perm[7] == "w") $chmod = $chmod+0002;
    if($perm[8] == "x") $chmod = $chmod+0001;
    return $chmod;
  }

  function copy_dir($ftp_from,$ftp_to,$dir_from,$dir_to,$perm,$lev)
  {
    echo str_repeat("|",$lev-1)."-Создание <b>$dir_to</b>..."; flush();
    $no_errors = true;
    $dir_list_to = explode("/",$dir_to);
    foreach($dir_list_to as $dir)
    { $dir_exist = false;
      $dir_list = ftp_rawlist($ftp_to,".");
      foreach($dir_list as $file)
        if($file[0] == "d" && substr($file,strrpos($file," ")+1) == $dir)
        { $dir_exist = true;
          break;
        }
      if($dir_exist) $no_errors = ($no_errors &&
                                   ftp_site($ftp_to,"chmod 0777 $dir") &&
                                   ftp_chdir($ftp_to,$dir));
      else $no_errors = ($no_errors &&
                         is_string(ftp_mkdir($ftp_to,$dir)) &&
                         ftp_site($ftp_to,"chmod 0777 $dir") &&
                         ftp_chdir($ftp_to,$dir));
    }
    if($no_errors) echo" OK<br>";
    else echo"<b> Error!</b><br>";
    flush();

    if(ftp_chdir($ftp_from,$dir_from))
      echo str_repeat("|",$lev-1)."-Переход в <b>$dir_to</b><br>";
    else echo str_repeat("|",$lev-1)."-<b>Error:</b> Ошибка перехода в <b>$dir_to</b><br>";
    flush();

    echo str_repeat("|",$lev)."-Чтение содержимого <b>$dir_from</b><br>";
    flush();

    $dir_list = ftp_rawlist($ftp_from,".");

    foreach($dir_list as $file)
      if($file[0] == "-")
      { $fperm = substr($file,1,9);
        $fname = substr($file,strrpos($file," ")+1);
        $chmod = getchmod($fperm);

        echo str_repeat("|",$lev)."--Копирование файла <b>$fname</b>..."; flush();
        if((@ftp_get($ftp_from,"tf.fl",$fname,FTP_BINARY) ||
            @ftp_get($ftp_from,"tf.fl",$fname,FTP_ASCII)) &&
           (@ftp_put($ftp_to,$fname,"tf.fl",FTP_BINARY) ||
            @ftp_put($ftp_to,$fname,"tf.fl",FTP_ASCII)) &&
           ftp_site($ftp_to,"chmod ".base_convert($chmod,10,8)." $fname") &&
           unlink("tf.fl")) echo" OK<br>";
        else echo"<b> Error!</b><br>";
      }

    foreach($dir_list as $file)
      if($file[0] == "d")
      { set_time_limit(300);
        $fperm = substr($file,1,9);
        $fname = substr($file,strrpos($file," ")+1);

        if($fname <> "." && $fname <> "..")
        { echo str_repeat("|",$lev)."-Копирование дирректории <b>$fname</b>...<br>"; flush();
          copy_dir($ftp_from,$ftp_to,$fname,$fname,$fperm,$lev+1);
        }
      }

    echo str_repeat("|",$lev)."-Переход <b>наверх</b>..."; flush();
    for($j = 0; $j <= substr_count($dir_to,"/"); $j++)
      ftp_cdup($ftp_to);
    if(ftp_cdup($ftp_from)) echo" OK<br>";
    else echo"<b> Error!</b><br>";
    flush();

    $chmod = getchmod($perm);
    if(ftp_site($ftp_to,"chmod ".base_convert($chmod,10,8)." ".$dir_to))
      echo str_repeat("|",$lev)."-На <b>$dir_to</b> установлен chmod(0".base_convert($chmod,10,8).")<br>";
    else echo str_repeat("|",$lev)."-<b>Error:</b> Ошибка установки chmod(0".base_convert($chmod,10,8).") на <b>$dir_to</b><br>";
    flush();
  }

  if(empty($_POST)) {?>
<html>

<head>
  <title>Переезд</title>

<script language='JavaScript'>
var kop_on = new Image(); kop_on.src = 'kop_on.jpg';
var kop_off = new Image(); kop_off.src = 'kop_off.jpg';
</script>

<script language='JavaScript'>
function procform()
{ var f = document.forms['cform'];

  var rexp = /^[a-z_\d\-\.]{8,64}$/;
  f.host_from.value = f.host_from.value.toLowerCase();
  if (!rexp.test(f.host_from.value))
  { alert('Недопустимый FTP-сервер FROM');
    return false;
  }
  f.host_to.value = f.host_to.value.toLowerCase();
  if (!rexp.test(f.host_to.value))
  { alert('Недопустимый FTP-сервер TO');
    return false;
  }

  rexp = /^[a-z_\d\-]{4,32}$/;
  f.user_from.value = f.user_from.value.toLowerCase();
  if (!rexp.test(f.user_from.value))
  { alert('Недопустимый логин FROM');
    return false;
  }
  f.user_to.value = f.user_to.value.toLowerCase();
  if (!rexp.test(f.user_to.value))
  { alert('Недопустимый логин TO');
    return false;
  }

  rexp = /^[a-zA-Z0-9]{4,32}$/;
  if (!rexp.test(f.pass_from.value))
  { alert('Недопустимый пароль FROM');
    return false;
  }
  if (!rexp.test(f.pass_to.value))
  { alert('Недопустимый пароль TO');
    return false;
  }

  f.action = 'ftp_copy.php';
  return true;
}
</script>
</head>

<body bgcolor=#C4E1E1>

<form name="cform" action="ftp_copy.php" method="post" onsubmit="return procform();">
<table width=80% align=center>
<tr>
  <td width=50% align=center>
    <big><b>Съезжаем с:</b></big><br><br>
    FTP-адрес: <input name="host_from" type="text" value="ftp."><br>
    Логин: <input name="user_from" type="text" value="user_from"><br>
    Пароль: <input name="pass_from" type="password" value="pass_from"><br><br>
    Список дирректорий для копирования:<br>
    <textarea name="dir_list_from" rows=5 cols=50 wrap="off"></textarea>
  </td>
  <td align=center>
    <big><b>Съезжаем к:</b></big><br><br>
    FTP-адрес: <input name="host_to" type="text" value="ftp."><br>
    Логин: <input name="user_to" type="text" value="user_to"><br>
    Пароль: <input name="pass_to" type="password" value="pass_to"><br><br>
    Соответствующие имена создаваемых дирректорий:<br>
    <textarea name="dir_list_to" rows=5 cols=50 wrap="off"></textarea>
  </td>
</tr>
</table>
<table width=80% align=center>
<tr><td width=15% valign=top>Примечания:</td>
<td>* Имя каждой дирректории должно занимать одну строку.<br>
* Каждой строке дирректорий ОТ должна соответствовать строка дирректорий В.<br>
* Все имена дирректорий указываются от верхнего уровня Вашего аккаунта.<br>
* В путях копирования нельзя использовать линки вместо папок, на которые они указывают.<br>
* Все копируемые дирректории, а также их подпапки должны иметь chmod минимум 500.<br>
* Chmod всех файлов в копируемых дирректориях должен быть не менее 400.
</td></tr></table><br>
<div align="center">
<input type=image src="kop_off.jpg" width=184 height=27 border=0 onmouseover="this.src=kop_on.src" onmouseout="this.src=kop_off.src" alt="КОПИРОВАТЬ">
</div>
</form>
</body>

</html>
<?php }else{
  set_time_limit(3000);
  $host_from = $_POST["host_from"];
  $ip_from = @gethostbyname($host_from);
  if($ip_from == $host_from) exit("Сервер <b>$host_from</b> НЕ найден.");
  else
  { echo"Соединение с <b>$host_from</b> ($ip_from)..."; flush();
    $ftp_handle_from = @ftp_connect($ip_from);
    if (!$ftp_handle_from) exit(" Ошибка соединения!");
    else echo" Соединение установлено.<br>";
    echo"Авторизация <b>$host_from</b>..."; flush();
    $user_from = $_POST["user_from"];
    $pass_from = $_POST["pass_from"];
    if(!@ftp_login($ftp_handle_from,$user_from,$pass_from)) { echo" Авторизация не удалась<br>";
                                                              echo"Выход <b>$host_from</b>..."; flush();
                                                              @ftp_quit($ftp_handle_from);
                                                              exit(" Соединение закрыто."); flush();
                                                            }
    else echo" ОK!<br>"; flush();
  }

  $host_to = $_POST["host_to"];
  $ip_to = @gethostbyname($host_to);
  if($ip_to == $host_to) { echo"Сервер <b>$host_to</b> НЕ найден.<br>";
                           echo"Выход <b>$host_from</b>..."; flush();
                           @ftp_quit($ftp_handle_from);
                           exit(" Соединение закрыто."); flush();
                         }
  else
  { echo"Соединение с <b>$host_to</b> ($ip_to)..."; flush();
    $ftp_handle_to = @ftp_connect($ip_to);
    if (!$ftp_handle_to) { echo" Ошибка соединения!<br>";
                           echo"Выход <b>$host_from</b>..."; flush();
                           @ftp_quit($ftp_handle_from);
                           exit(" Соединение закрыто."); flush();
                         }
    else echo" Соединение установлено.<br>";
    echo"Авторизация <b>$host_to</b>..."; flush();
    $user_to = $_POST["user_to"];
    $pass_to = $_POST["pass_to"];
    if(!@ftp_login($ftp_handle_to,$user_to,$pass_to)) { echo" Авторизация не удалась<br>";
                                                        echo"Выход <b>$host_to</b>..."; flush();
                                                        @ftp_quit($ftp_handle_to);
                                                        echo" Соединение закрыто.<br>"; flush();
                                                        echo"Выход <b>$host_from</b>..."; flush();
                                                        @ftp_quit($ftp_handle_from);
                                                        exit(" Соединение закрыто."); flush();
                                                      }
    else echo" ОK!<br>"; flush();
  }

  $dir_list_from = str_replace("\r\n","\n",$_POST["dir_list_from"]);
  $dir_list_to = str_replace("\r\n","\n",$_POST["dir_list_to"]);

  $dir_list_from = explode("\n",$dir_list_from);
  $dir_list_to = explode("\n",$dir_list_to);

  while(($dir_list_from[0] == "") && (sizeof($dir_list_from) > 1)) array_shift($dir_list_from);
  while(($dir_list_to[0] == "") && (sizeof($dir_list_to) > 1)) array_shift($dir_list_to);

  while($key = array_search("",$dir_list_from)) { unset($dir_list_from[$key]);
                                                  $dir_list_from = array_values($dir_list_from);
                                                }
  while($key = array_search("",$dir_list_to)) { unset($dir_list_to[$key]);
                                                $dir_list_to = array_values($dir_list_to);
                                              }
  if($dir_list_from[0] == "")
    echo"<b>Список дирректорий ОТ не должен быть пустым!</b><br>";
  elseif($dir_list_to[0] == "")
    echo"<b>Список дирректорий В не должен быть пустым!</b><br>";
  elseif(($dir_co = sizeof($dir_list_from)) != sizeof($dir_list_to))
    echo"<b>Количество дирректорий ОТ и дирректорий В должно быть одинаковым!</b><br>";
  else
  { echo"<font face=\"Courier\">";
    for($i = 0; $i < $dir_co; $i++)
    { $dir_list_from[$i] = str_replace("\\","/",$dir_list_from[$i]);
      $dir_list_from[$i] = str_replace("//","/",$dir_list_from[$i]);
      if($dir_list_from[$i][0] == "/") $dir_list_from[$i] = substr($dir_list_from[$i],1);
      if($pos = strrpos($dir_list_from[$i],"/"))
      { $up_dir_from = substr($dir_list_from[$i],0,$pos);
        $copy_dir_from = substr($dir_list_from[$i],$pos+1);
      }
      else
      { $up_dir_from = "";
        $copy_dir_from = $dir_list_from[$i];
      }
      if($up_dir_from)
      { echo"Переход в ".$up_dir_from."..."; flush();
        if(@ftp_chdir($ftp_handle_from,$up_dir_from))
          echo" OK<br>";
        else echo"<b> Error!</b><br>";
      }
      $dir_list = @ftp_rawlist($ftp_handle_from,".");
      $perm = "";
      foreach($dir_list as $file)
        if($file[0] == "d" && substr($file,strrpos($file," ")+1) == $copy_dir_from)
        { $perm = substr($file,1,9);
          break;
        }
      if(!$perm) { echo"Дирректория <b>".$dir_list_from[$i]."</b> не найдена!<br>"; flush(); }
      else
      { echo"Копирование дирректории <b>".$dir_list_from[$i]."</b> в <b>".$dir_list_to[$i]."</b>...<br>"; flush();
        copy_dir($ftp_handle_from,$ftp_handle_to,$copy_dir_from,$dir_list_to[$i],$perm,1);
      }
      for($j = 0; $j <= substr_count($up_dir_from,"/"); $j++)
        @ftp_cdup($ftp_handle_from);
    }
    echo"</font>";
  }

  echo"Выход <b>$host_to</b>..."; flush();
  @ftp_quit($ftp_handle_to);
  echo" Соединение закрыто.<br>"; flush();

  echo"Выход <b>$host_from</b>..."; flush();
  @ftp_quit($ftp_handle_from);
  echo" Соединение закрыто."; flush();

}?>