https://nakedsecurity.sophos.com/2014/09/02/using-wps-may-be-even-more-dangerous/
http://xn--mric-bpa.fr/blog/blackjack.html
https://forums.kali.org/showthread.php?24286-WPS-Pixie-Dust-Attack-(Offline-WPS-Attack)&p=43000&viewfull=1#post43000
https://bitbucket.org/dudux/wpsoffline/
