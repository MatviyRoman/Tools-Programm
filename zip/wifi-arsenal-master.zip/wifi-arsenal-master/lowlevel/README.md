
http://www.irongeek.com/i.php?page=videos/defcon-wireless-village-2014/20-inside-the-atheros-wifi-chipset-adrian-chadd

http://luci.subsignal.org/~jow/reghack/