hashcat-utils
==============

Hashcat-utils are a set of small utilities that are useful in advanced password cracking

Brief description
--------------

They all are packed into multiple stand-alone binaries.

All of these utils are designed to execute only one specific function.

Since they all work with STDIN and STDOUT you can group them into chains.

Detailed description
--------------

tbd

Compile
--------------

Simply run make

Binary distribution
--------------

Binaries for Linux, Windows and OSX: https://github.com/hashcat/hashcat-utils/releases
